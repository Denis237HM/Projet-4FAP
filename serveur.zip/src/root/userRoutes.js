const express = require('express');
/*recuperation de toutes les methodes du fichier controlleur et leur sontockage dans la variable controller*/
const controller = require('../controlleur/usercontrolleur.js');

const multer = require('../midleware/multer-config');
const router = express.Router();//importation du module permettant le routage

/*le premeier parametre  des routes ci-dessous constitu le chemin d'acces
 et ce chemin d'acces est choisie de façon  artraire en clair chacun met le chemin qu'il veut
 mais il faut rester exlicite au risque de se perdre dans les fichiers 
 et le deixiemme parametre est la methode meme à la quelle on accede dans le fichier controlleur*/
//router.post('/create',multer, controller.create); //multer,
router.get('/selectOneuser',controller.findOne);
router.get('/selectAlluser', controller.findAll);
router.put('/modifyAll', controller.editAt);//cette mise à jour retourne toutes les informations d'un utilisateur
router.put('/updeteall', multer, controller.updateUser);//cette mise à jour retourne seulement l'id de l'utilisateur
router.delete('/deleteoneuser/:userid',controller.deleteOne);
router.post('/verify2fa', controller.verify2fa);
router.post('/auth', controller.enable2fa);
router.post('/create',controller.create);
router.post('/login',controller.LoginUser);
//router.post('/singIn', controller.singIn);

module.exports = router;/*exportation des routes pour le fichier de demarrage*/