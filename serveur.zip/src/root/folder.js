const express = require('express');

/*recuperation de toutes les methodes du fichier controlleur et leur sontockage dans la variable controller*/
const controller = require('../controlleur/folder.js');
const file = require('../controlleur/files.js');
const auth = require('../midleware/auth.js');
const multer = require('../midleware/multer-config.js');
const router = express.Router();//importation du module permettant le routage


router.post('/create/:userId',controller.create);

router.post('/file/:userId',file.create);
router.get('/get/:userId',controller.findAllOneUser);
router.delete('/delete/:id',controller.delete);
router.delete('/upload/:id',file.delete);
router.get('/find/:folderId', file.findAllOneFolder);
router.get('/collab/:id', controller.update);


module.exports = router;