const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

module.exports = (req, res, next) => {
  try {
      const token = req.headers.authorization.split(' ')[1];
      // console.log("voici le token venu"+token)
      const decodedToken = jwt.verify(token, `${process.env.RANDOM_TOKEN_SECRET}`);
      const userId = decodedToken.UserId;
      const admin = decodedToken.admin;
      const matricule = decodedToken.matricule;
      console.log("ici le matricule" + matricule)
         req.auth = { userId, admin ,matricule};
    if (req.body.userId && req.body.userId !== userId) {
      throw 'Invalid user ID';
    } else {
      next();
    }
  } catch {
    res.status(401).json({
      error: new Error('Invalid request!')
    });
  }
};