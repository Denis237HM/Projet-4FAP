const nodemailer = require('nodemailer')

const transporteur = nodemailer.createTransport({
    host:"smtp-mail.outlook.com",
    secureConection: false,
    port:587,
    tls:{
        ciphers:"SSLv3"
    },
    auth:{
        user:"julescodeTest@outlook.com",
        pass:"test_111zr5687tc"
    }
})
const mailoption={
    from:"julescodeText@outlook",
    to:"cexoso7540@pixiil.com",
    subjet:"mail automatique",
    text:"c'est un message automatique"
}
transporteur.sendMail(mailoption, (error, info) =>{
    if(error){
           console.log(error)
    }else{
        console.log("message mail envoyé"+info.response)
    }
})

module.exports = transporteur;