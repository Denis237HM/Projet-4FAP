const controller = {};
const db = require('../models');


controller.create = (req, res, next) => {
  const file = {
    path: req.file.path,
    folderId: req.params.folderId // Utilisez le nom de paramètre correct
  };

  db.Files.create(file)
    .then((createdFile) => {
      console.log(createdFile);
      res.status(200).json({ message: "Fichier créé avec succès", id: createdFile.id });
    })
    .catch((error) => res.status(400).json({ error }));
};

controller.delete = (req, res) => {
    db.Files.findOne({ where: { id: req.params.id } })
        .then((Folder) => {

            
            db.Files.destroy({ where: { id: req.params.id } })
                .then(() => res.status(200).json({ message: 'fichier supprimer avec succès !' }))
                .catch((error) => res.status(400).json({ error }))
            } 
        )
        .catch((error) => {
            console.log(error);
            res.status(500).json({ error })
        });
};

// Router


// Controller
controller.findAllOneFolder = (req, res, next) => {
    db.Files.findAll({
        where: {folderId : req.params.folderId},
        order: [['createdAt', 'ASC']],
    })
        .then((files) => {
            res.status(200).json(files);
        })
        .catch((error) => {
            res.status(500).json(error);
        });
};



module.exports = controller;