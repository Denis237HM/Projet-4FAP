const controller = {};
//const fs = require('fs');
const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const passwordValidator = require('password-validator');
const db = require('../models');
const { token } = require('morgan');
const OTPAuth = require("otpauth");
const encode = require("hi-base32");
const QRCode = require('qrcode');
const crypto = require('crypto');


const schemapassword = new passwordValidator();
schemapassword
    .is().min(8)
    .is().max(100)
    .has().uppercase()
    .has().lowercase()
    .has().digits(2)
    .has().not().spaces()
    .is().not().oneOf(['Passw0rd', 'Password123']);




controller.create = (req, res) => {

    const variableuser = {
        firstName: req.body.firstName,

        lastName: req.body.lastName,
        email: req.body.email,
        password: req.body.password
        
    
    };
                db.User.create(variableuser).then((id) => {
                    console.log("l'utilisateur crée avec succes")
                    res.status(201).send({
                        status: "success",
                        message: "User created successfully"
                      });
                }).catch((err) => {
                    console.error(err);
                });

           
    //fin de la clause sinon
};


// Endpoint to enable two-way authentication
controller.enable2fa = async (req, res) => {
  const { email } = req.body;

  // Find the user by email
  const user = await db.User.findOne({
    where: {
      email: email,
    },
  });

  if (!user) {
    return res.status(404).send('User not found');
  }

  // Generate a secret key for the user
  const base32Secret = await generateBase32Secret();
  user.secret2fa = base32Secret;

    await user.save();

    console.log(user);


  // Generate a QR code URL for the user to scan
  let totp = new OTPAuth.TOTP({
    issuer: "YourSite.com",
    label: "YourSite",
    algorithm: "SHA1",
    digits: 6,
    secret: base32Secret,
  });

  let otpauth_url = totp.toString();

  // Generate and send the QR code as a response
  QRCode.toDataURL(otpauth_url, (err, qrUrl) => {
    if (err) {
      return res.status(500).json({
        status: 'fail',
        message: "Error while generating QR Code",
      });
    }
    res.json({
      status: "success",
      data: {
        qrCodeUrl: qrUrl,
        secret: base32Secret,
      },
    });
  });
};
const generateBase32Secret = async () => {
  const { default: base32 } = await import('base32-encode');
  const buffer = crypto.randomBytes(15);
  const base32Secret = base32(buffer, 'RFC4648');
  return base32Secret;
};




//verification 


controller.verify2fa = async (req, res) => {
  const { email, token } = req.body;

  // Find the user by email
  const user = await db.User.findOne({
    where: {
      email: email,
    },
  });

  if (!user) {
    return res.status(404).send('User not found');
  }

  // Verify the token
  let totp = new OTPAuth.TOTP({
    issuer: "YourSite.com",
    label: "YourSite",
    algorithm: "SHA1",
    digits: 6,
    secret: user.secret2fa,
  });

 /* if (delta === null) {
    return res.status(401).json({
      status: "fail",
      message: "Authentication failed",
    });
  }*/

  // Update the user's 2FA status
  console.log(token)
  console.log(totp.validate({ token })
)
 let delta = totp.validate({ token });

if (delta === null) {
  return res.status(401).json({
    status: "fail",
    message: "Échec de l'authentification",
  });
} else {
  // Mise à jour du statut 2FA de l'utilisateur
  if (!user.enable2fa) {
    user.enable2fa = true;
    await user.save();
  }
  console.log(user);

  res.json({
    status: "success",
    data: {
      otp_valid: true,
    },
  });
}
};

controller.LoginUser = async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await db.User.findOne({ where: { email: email } });

    if (!user || user.password !== password) {
      return res.status(401).json({
        status: "fail",
        message: "Invalid email or password",
      });
    }

    res.status(200).json({
      status: "success",
      data: {
        user: {
          id: user.id,
          firstname: user.firstName,
          lastname: user.lastName,
          enabled2fa: user.enable2fa,
        },
      },
    });
  } catch (error) {
    return res.status(500).json({
      status: "fail",
      message: "Something went wrong while logging in",
    });
  }
};








  
/*la fonction de mise à jour ci-dessous ne retourne que l'id de l'utilisateur*/
controller.updateUser = (req, res, next) => {
    const updateProfilUser = {
        lastName: req.body.lastName,
        firstName: req.body.firstName,
        email: req.body.email,
        photoavant: req.body.files,
        photoavariere: req.body.files,
        NumeroCNI: req.body.NumeroCNI,
        Telephone: req.body.Telephone,
        sexe: req.body.sexe,
    };
    if(req.file != undefined){
        updateProfilUser.photoavant = `${req.protocol}://${req.get("host")}/images/${req.file.filename}`;
        updateProfilUser.photoavariere = `${req.protocol}://${req.get("host")}/images/${req.file.filename}`;
    }
    db.User.update(
        updateProfilUser,
        { where: { id: req.auth.userId } })
        .then((users) => {
            console.log(updateProfilUser);
            res.status(200).json({message : "utilisateur modifié avec succès"})
        })
        .catch((error) => res.status(400).json({ error }))
};

controller.findAll = (req, res) => {
    db.User.findAll({

        order: [['id', 'ASC']],

    }).then((users) => {
        res.status(200).json(users);
    }).catch((err) => {
        console.log(err);
    });
};
/*donne internet :la fonction de mise à jour ci-dessous retourne toutes le information de l'utilisateur */

controller.editAt = async function (req, res) {
    try {
        db.User
            .findOne({ where: { id: req.auth.userId } })
            .then(async (result) => {
                if (result.length > 0) {
                    db.User.update(
                        {
                            lastName: req.body.lastName,
                            firstName: req.body.firstName,
                            email: req.body.email,
                            photoavant: req.body.photoavant,
                            photoavariere: req.body.photoavariere,
                            NumeroCNI: req.body.NumeroCNI,
                            Telephone: req.body.Telephone,
                            sexe: req.body.sexe,
                        },
                        { where: { id: req.body.id } }
                    );
                    res.status(200).json({
                        message: "Mise à jour reussie ",
                        data: {
                            id: req.body.id,
                            lastName: req.body.lastName,
                            firstName: req.body.firstName,
                            email: req.body.email,
                            photoavant: req.body.photoavant,
                            photoavariere: req.body.photoavariere,
                            NumeroCNI: req.body.NumeroCNI,
                            Telephone: req.body.Telephone,
                            sexe: req.body.sexe,
                        },
                    });
                } else {
                    res.status(500).json({ message: "echec ce la mise à jour" });
                }
            });
    } catch (error) {
        res.status(404).json({ message: error });
    }
};
/*les données d'en haut viennent de l'internet*/


controller.findOne = (req, res) => {
    db.User.findOne({
         where: { id: req.auth.userId } ,
         attributes: [ "id","lastName", "firstName", "email", "matricule", "photoavant","Telephone","NumeroCNI","roleID"], 
        }).then((user) => {
   
        if(!user){
            res.status(400).json({ message: "l'utilisateur n'esxixte pas" })
        }else{
            res.status(200).json(user);
        }
    }).catch((err) => {
        console.log(err);
    });
};

controller.deleteOne = (req, res) => {

    db.User.findOne({ where: { id: req.params.id }, })
        .then((User) => {
            if (!User) {
                res.status(400).json({ message: "l'utilisateur n'esxixte pas" })
            } else {
                db.User.destroy({
                    where: { id: req.params.id },
                }).then(() => {
                    res.status(200).json({ message: "l'utilisateur a été  suprimer avec succes" })
                }).catch((err) => {
                    console.log(err);
                })
            }
        }).catch((err) => { console.log(err); res.status(500).json(err) })
};



//fonction de connection 
controller.login = (req, res, next) => {
    const loginEmail = req.body.email;
    const loginPassword = req.body.password;

    db.User.findOne({ where: { email: loginEmail } })
        .then((User) => {
            if (User == null) {
                return res.status(401).json({ error: "L'utilisateur n'existe pas" });
            }
            if (req.body.email == "admin@admin.fr") {
                res.status(200).json({
                    userId: User.id,
                    token: jwt.sign(
                        { userId: User.id, admin: User.admin },
                        `${process.env.RANDOM_TOKEN_SECRET}`,
                        { expiresIn: '24h' }
                    )
                });
            }
            else {
                bcrypt.compare(loginPassword, User.password).then((valid) => {
                    if (valid == false) {
                        // Si le mot de passe est incorrecte
                        return res.status(401).json({ error: "Mot de passe incorrect !" });
                    }
                    //res.cookie('jwt', token,{httpOnly : true ,maxAge:'24h'})
                    res.status(200).json({
                        userId: User.id,
                        token: jwt.sign(
                            { UserId: User.id , matricule : User.matricule},
                            `${process.env.RANDOM_TOKEN_SECRET}`,
                            { expiresIn: '24h' }
                        ) 
                        
                    });
                    console.log("voici mon token ici")
                    console.log(token);
                   // token()
                })
            }
        })
        .catch((error) => res.status(500).json({ error }));
};

controller.logout = (req, res) => {
    res.clearCookie("jwt");
    res.status(200).json("OUT");
};


module.exports = controller;

// const maxAge = 20*60*60*1000
// const createToken = (id) =>{
//     return jwt.sign({id},'CLES DE TOKEN SECRET',
//      {expiresIn : maxAge}
//     )
// };
// module.exports.singIn = async(req,res,next) =>{
//     const {email,password} = req.body ;
//     try {
//         const user = db.User.login(email,password);
//         const token= createToken(user.id);
//         res.cookie('jwt', token,{httpOnly : true ,maxAge:maxAge})
//         res.status(200).json({user : user.id})
//     } catch (error) {
//         console.log(error)
        
//     }
// }