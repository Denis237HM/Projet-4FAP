const controller = {};
const db = require('../models');


controller.create = (req, res, next) => {
    const operation = {
        name: req.body.name,
        matricule_recepteur : req.body.matricule_recepteur,
        // images: req.body.files,
        type_operation: req.body.type_operation,
        observation: 0,
        userId: req.auth.userId
    };
    console.log(req.body);
    if (req.file != undefined) {
        operation.images = `${req.protocol}://${req.get("host")}/images/${req.file.filename}`;
    }
    db.Operation.create(operation)
        .then((id) => {
            res.status(200).json({ message: "operation initiée avec succès", id: id })
            // res.status(200).json(id);
        })
        .catch((error) => res.status(400).json({ error }))
};

controller.findAll = (req, res, next) => {
    db.Operation.findAll({
        order: [['createdAt', 'DESC']], 
        // include: 'users'
    })
        .then((operations) => {
            res.status(200).json( operations )
        })
        .catch((error) => {
            res.status(500).json(error)
        })

};



controller.findAllOneUser = (req, res, next) => {
    db.Operation.findAll({
        where: {userId : req.auth.userId},
        order: [['createdAt', 'DESC']],
    })
        .then((operations) => {
            res.status(200).json( operations )
        })
        .catch((error) => {
            res.status(500).json(error)
        })
};


controller.findOne = (req, res, next) => {
    db.Operation.findOne({
        where: { id: req.params.id , userId : req.auth.userId }
    })
        .then((Operation) => {
            res.status(200).json(Operation)
        })
        .catch((error) => {
            res.status(500).json(error)
        })
};

controller.delete = (req, res) => {
    db.Operation.findOne({ where: { id: req.params.id } })
        .then((Operation) => {

             if (req.auth.userId == Operation.userId) {
            db.Operation.destroy({ where: { id: req.params.id } })
                .then(() => res.status(200).json({ message: 'operation supprimer avec succès !' }))
                .catch((error) => res.status(400).json({ error }))
            } else {
               res.status(400).json({ message: "vous ne pouvez pas suprimer cette operation car vous n'êtes pas l'auteur" })
             }
        })
        .catch((error) => {
            console.log(error);
            res.status(500).json({ error })
        });
};


/*litiger une operation*/
controller.update = (req, res, next) => {
    console.log(req.body);
    db.Operation.findOne({ where: { id: req.params.id } })
        .then((Operation) => {
            const newValue = { observation : 2 };
            
            if (req.auth.admin || req.auth.userId == Operation.userId){

                db.Operation.update(newValue, {
                    where: {id : req.params.id }
                })
                    .then(() => res.status(200).json({ message: 'operation modifiée avec succes' }))
                    .catch(error => {
                        console.log(error);
                        res.status(400).json({ error: 'Impossible de modifier l\'operation car vous n\'êtes pas l\'aureut de cette operation', error });
                    })
            }
            else {
                console.log("test");
                res.status(400).json({ error: 'Impossible de modifier cette operation car vous n\êtes pas l\'auteur', error });
            }
        })
        .catch(error => res.status(400).json({ error: 'Impossible de modifier cette operation', error }));
};


controller.operationvalideted = (req, res) => {
    db.Operation.findOne({ where: { id: req.params.id } }).then((Operation) => {
        const observation = { observation: 1 };
        if (!Operation || Operation.userId != req.auth.userId) {
            res.status(400).json({ message: "operation introuvable" })
        } else {

            db.Operation.update(observation, { where: { id: req.params.id } })
                .then(() => {
                    res.status(200).json({ message: "operation valider avec success" })
                })
                .catch((error) => { console.log(error) })
        }
    }).catch((err) => console.log(err));
};
controller.miserajouroperation = (req,res) => {
   db.Operation.findOne({where : {id: req.params.id}}).then((Operation) =>{

    if(Operation){
       if((Operation.userId == req.auth.userId)){
        const operation = {
            name: req.body.name,
            // images: req.body.files,
            type_operation: req.body.type_operation,
            observation: 0
            }
            db.Operation.update(operation, {where :{ id : req.params.id },}).then(() => res.status(200).json({message : "Mise à jour validée"}))
       }else{
         res.status(400).json({message : "Vous ne pouvez pas modifier cette operation car vous 'êtespasl'auteeur"})
       }
    }

   }).catch((error) => res.status(400).json(error))
};

controller.getOne = (req,res) =>{
    db.Operation.findOne({
        where: { name: req.params.name , type_operation : req.params.type_operation}
    })
        .then((Operation) => {
            res.status(200).json(Operation)
        })
        .catch((error) => {
            res.status(500).json(error)
        })
};

/*Methode permettant d'obtenir toutes les operations d'un utilisateur*/
controller.getoperations = (req,res) =>{
  db.Operation.findAll({where : {userId: req.auth.userId }}).then((Operation) =>{
    res.status(200).json(Operation)
  }).catch((error) => console.log(error))
};

/*Methodes qui gèrent les operations transfert argent-argent*/
controller.depot = (res,req) =>{
    const montant = req.body.montant ;
    db.Operation.findOne({
        where: { id: req.params.id },
        attributes: ["type_operation"]
    }).then((Operation) => {
        if (Operation) {
            if (Operation.type_operation == "Argent-Argent") {
                db.Detail.create({
                    name: "Frais trust",
                    valeur : montant * 0.05
                }).then((Detail) => {
                    res.status(200).json(Detail)
                }).catch((error) => console.log(error))
            } 
        }//on verifie si le resulta de la requette n'est pas vide

    }).catch((error) => res.status(500).json(error))
};

/*enregistrement d'une operation de transfert d'argent*/
controller.createtransfert = (req, res, next) => {
    const operation = {
        name: req.body.name,
        matricule_recepteur : req.body.matricule_recepteur,
        observation: 0,
        userId: req.auth.userId
    };
    db.Operation.create(operation)
        .then((id) => {
            res.status(200).json({ message: "operation initiée avec succès", id: id })
            // res.status(200).json(id);
        })
        .catch((error) => res.status(400).json({ error }))
};

/*faire un epot*/
controller.faireDepot = (req,res) =>{
   const depot = { 
       numeroDeteur : req.body.numeroDeteur,
       montantCredit : req.body.montantCredit
   };
};
/*obtention de toute les operations dont le champ matricule est egale au matricule de l'utilisateur connecté*/
controller.findAllOperatuionmatricule = (req ,res) =>{
    db.Operation.findAll({
        order: [['createdAt', 'DESC']], 
        where : {matricule_recepteur : req.auth.matricule}
    })
        .then((operations) => {
            res.status(200).json( operations )
        })
        .catch((error) => {
            res.status(500).json(error)
        })
};

// controller.rehercheroperation = (req,res) =>{
//     db.Operation.findAll({
//         where :{name : "'%'+ req.body.name +'%' "}
//     })
// };
   


module.exports = controller;