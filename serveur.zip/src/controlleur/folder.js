const controller = {};
const db = require('../models');


controller.create = (req, res, next) => {
    const folder = {
        name: req.body.name,
        userId: req.params.userId ,
        collaborateur:"null"// Récupérer l'userId à partir des paramètres de la requête
    };

    console.log(req.body);

    // Utilisez l'userId dans votre logique de création du dossier ou pour effectuer des opérations spécifiques à cet userId

    db.Folder.create(folder)
        .then((folder) => {
            console.log(folder);
            res.status(200).json({ message: "Dossier créé avec succès", id: folder.id });
        })
        .catch((error) => res.status(400).json({ error }));
};
controller.findAllOneUser = (req, res, next) => {
    db.Folder.findAll({
        where: { userId: req.params.userId },
        order: [['createdAt', 'DESC']],
    })
        .then((folders) => {
            res.status(200).json(folders)
        })
        .catch((error) => {
            res.status(500).json(error)
        })
};


controller.delete = (req, res) => {
    db.Folder.findOne({ where: { id: req.params.id } })
        .then((Folder) => {


            db.Folder.destroy({ where: { id: req.params.id } })
                .then(() => res.status(200).json({ message: 'dossier supprimer avec succès !' }))
                .catch((error) => res.status(400).json({ error }))
        }
        )
        .catch((error) => {
            console.log(error);
            res.status(500).json({ error })
        });
};



/*litiger une operation*/
controller.update = (req, res, next) => {
   const newValue = { collaborateur: req.body.collaborateur };
db.Folder.update(newValue, {
    where: { id: req.params.id }
})
.then(() => {
    res.status(200).json({ message: 'collaborateur modifié avec succes' });
})
.catch(error => {
    console.log(error);
    res.status(400).json({ error: 'Impossible de modifier le collaborateur car vous n\'êtes pas l\'aureut de ce collaborateur', error });
});
};


module.exports = controller;