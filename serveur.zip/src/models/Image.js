'use strict';
const { Model } = require('sequelize');
const moment = require('moment');

module.exports = (sequelize, DataTypes) => {

  class Image extends Model  {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */  
   
    /*relation entre operation et ses tables associées*/
    static associate({ User }) {

      this.belongsTo(User, {foreignKey: 'userId', as: 'users' });
      
     
    }
    toJSON(){ 
      return { ...this.get(), userId: undefined}
    }//la seule fonction à implementer 

  };
  Image.init({
  name: { 
        allowNull: false,  
        type: DataTypes.STRING
      },
 
},
 {
  sequelize,
  tableName: 'Images',
  modelName: 'Image',
});
return Image;
};