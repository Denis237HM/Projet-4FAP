    'use strict';
    const { Model } = require('sequelize');
    const moment = require('moment');
const Folder = require('./folder');
const Images = require('./Image');

    module.exports = (sequelize, DataTypes) => {

      class User extends Model  {
        /*
         * Helper method for defining associations.
         * This method is not a part of Sequelize lifecycle.
         * The `models/index` file will call this method automatically.
         */  
        /*relation utilisateur rt versement*/
        static associate({ Image,Folder, Files }){
          
           
            this.hasMany(Image, {foreignKey: 'userId', as: 'images'});
            this.hasMany(Folder, {foreignKey: 'userId', as: 'folders'});
            this.hasMany(Files, {foreignKey: 'userId', as: 'files'});

            
        } 
        toJSON(){
          return { ...this.get(), imageId: undefined, folder: undefined, file: undefined};
        }
      };
      User.init({
      firstName: { 
        allowNull: false,
        type: DataTypes.STRING
      },
     
      lastName: {
        type: DataTypes.STRING ,
        allowNull: false,
      },
      email: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      password: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      enable2fa: {
        type: DataTypes.BOOLEAN,
        default: false
      },
      secret2fa: {
        type: DataTypes.STRING
      
      },
   
    },
     {
      sequelize,
      tableName: 'Users',
      modelName: 'User',
    });
    return User;
  };