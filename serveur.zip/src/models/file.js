'use strict';
const { Model } = require('sequelize');
const moment = require('moment');

module.exports = (sequelize, DataTypes) => {

  class Files extends Model  {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` Files will call this method automatically.
     */  
   
    /*relation entre operation et ses tables associées*/
    static associate({ User , Folder}) {

      this.belongsTo(User, {foreignKey: 'userId', as: 'users' });
      this.belongsTo(Folder, {foreignKey: 'folderId', as: 'folders' });
      
     
    }
    toJSON(){ 
      return { ...this.get(), userId: undefined}
    }//la seule fonction à implementer 

  };
  Files.init({
  path: { 
        allowNull: false,  
        type: DataTypes.STRING
      },
       extension: { 
        allowNull: false,  
        type: DataTypes.STRING
      },
  name: { 
        allowNull: false,  
        type: DataTypes.STRING
      },
     ip: { 
        allowNull: false,  
        type: DataTypes.STRING
      },
       size: { 
        allowNull: false,  
        type: DataTypes.STRING
      },
 
 
 
 
},
 {
  sequelize,
  tableName: 'Files',
  modelName: 'Files',
});
return Files;
};