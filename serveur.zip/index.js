'use strict';
const express = require('express'); 
//const socket = require('socket.io') ;
//const mail = require('./src/mail/mail')
/*recuperation des routes de tous les models*/
const userRouter = require('./src/root/userRoutes');
const folderRoute = require('./src/root/folder');
const multer = require('multer');
const fs = require('fs');
/*les variable indispensable pour le fonctionnement de certains modules*/
const path = require("path");
const morgan = require('morgan');
const bodyParser = require('body-parser');
const helmet = require("helmet");
const cors = require('cors');
const app = express();
const PORT = 8000;
const CORS_OPTS = {
    origin: '*',
  
    methods: [
      'GET',
      'POST',
      'DELETE',
      'PUT',
    ],
  
    allowedHeaders: [
      'Content-Type',
      'Access-Control-Allow-Headers',
      'Origin, X-Requested-With, Content, Accept, Authorization',
    ],
  };
const db = require('./src/models');
const folder = require('./src/models/folder');

app.use(cors(CORS_OPTS));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());


//routings 
app.use('/trustapi/utilisateur/', userRouter);
app.use('/trustapi/dossier/', folderRoute);
/*app.use('/trustapi/critere/', critereRoot);
//app.use('/trustapi/detailversement/', detailversementRoot);
app.use('/trustapi/role/', roolrRoot);
app.use('/trustapi/detail/', detailRoot);
app.use('/trustapi/operation/', operationRoot);
app.use('/trustapi/moyenpayement/', moyenpayementRoot);*/





app
.use(morgan('dev'))
.use(bodyParser.json())
//.use("/images", express.static(path.join(__dirname, "images")))
.use(express.static(path.join(__dirname, 'public/uploads')))
.use(helmet())
// app.use (cors());

const storage = multer.diskStorage({

  destination: (req, file, cb) => {
     const DIR = `./public/uploads/${req.params.folderId}/`;
     if (!fs.existsSync(DIR)) {
      fs.mkdirSync(DIR);
    }
    cb(null, DIR);
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname);
  },
});
/*
const uploadMulter = multer.diskStorage({
  destination: (req, file, callback) => {
    const DIR = "./src/uploads/"+req.params.folderId+"/";
    console.log(DIR);
    if (!fs.existsSync(DIR)) {
      fs.mkdirSync(DIR);
    }
    callback(null, DIR);
  },
  filename: (req, file, callback) => {
    const extension = file.mimetype.split("/")[1];
    console.log(extension);
    const name = file.originalname.split("." + extension)[0];
    const namefile = name.split(" ").join("_");
    callback(null, Date.now() + "--" + namefile + "." + extension);
  },
});*/

const upload = multer({ storage });

//const io = socket('server')

// File Upload Endpoint
/*app.post('/upload', upload.single('file'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }
  
  const file = {
    path: req.file.path
  };

  db.Files.create(file)
    .then((createdFile) => {
      console.log(createdFile);
      res.status(200).json({ message: "Fichier créé avec succès", id: createdFile.id });
    })
    .catch((error) => res.status(400).json({ error }));
});
*/

app.post('/upload/:folderId', upload.single('file'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }
  
 const file = {
    path: req.file.path,
    folderId: req.params.folderId,
    name: req.file.filename.split("." + path.extname(req.file.filename))[0], // Nom de l'image
    extension: path.extname(req.file.filename), // Extension du fichier
    size: req.file.size, // Taille du fichier en octets
    ip: req.socket.remoteAddress // Adresse IP du client
  };
  console.log(file)
  db.Files.create(file)
    .then((createdFile) => {
      console.log(createdFile);
      res.status(200).json({ message: "Fichier créé avec succès", id: createdFile.id, folderId: createdFile.folderId });
    })
    .catch((error) => res.status(400).json({ error }));
});

// Récupération de l'heure système du client
const clientTime = new Date().getTime();
console.log('Heure du client :', clientTime);

// Récupération de l'heure système du serveur via une API
fetch('/get-server-time')
  .then(response => response.json())
  .then(data => {
    const serverTime = data.timestamp;
    console.log('Heure du serveur :', serverTime);

    const timeDiff = Math.abs(serverTime - clientTime);
    console.log('Différence de temps :', timeDiff, 'millisecondes');

    if (timeDiff > 300000) { // 5 minutes en millisecondes
      // L'horloge du client est désynchronisée, informer l'utilisateur
      console.log('Veuillez synchroniser votre horloge avant de continuer.');
    } else {
      // L'horloge du client est synchronisée, continuer le processus d'authentification 2FA
      console.log('Horloge synchronisée, continuons.');
    }
  })
  .catch(error => {
    console.error('Erreur lors de la récupération de heure du serveur :', error);
  });


db.sequelize.sync().then(() => {
    app.listen(PORT, ()=> console.log(`our application start good in port ${PORT}`));
});




//const PORT = 5000
//app.listen(PORT , () => console.log(`l'application est bien demarrée sur : https://localhost : ${PORT} `));
