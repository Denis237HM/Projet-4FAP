import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FolderService {
  private apiUrl = 'http://localhost:8000/trustapi/dossier'; 
   private Url = 'http://localhost:8000/upload';// Replace with your API endpoint URL

  constructor(private http: HttpClient) { }

  createFolder(folder: any,id: number ): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/create/${id}`, folder);
  }

  select(id: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/get/${id}`);
  }

   delete(id: number): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/delete/${id}`);
  }

  uploadFile(id: number, formData: FormData): Observable<any> {
  return this.http.post(`${this.Url}/${id}`, formData);


}

  selectFile(id: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/find/${id}`);
  }

   deleteFile(id: number): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/upload/${id}`);
  }

   update(folder: any,id: number ): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/collab/${id}`, folder);
  }

}
