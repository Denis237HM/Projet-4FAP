import { Component } from '@angular/core';

import { Router } from '@angular/router';
import { User } from '../folder/user';
import { UserService } from '../service/user.service';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrl: './sign-in.component.css'
})
export class SignInComponent {
  user: User;
  message: boolean | undefined;
  showMessage: boolean | undefined;
  validation: boolean = true;
  qrCodeUrl: any;
  hidden_email:any;
  constructor(private service: UserService,   private router: Router) {
    this.user = new User();
   }
   ngOnInit() {
    localStorage.clear();
    console.log(localStorage);
  
  }
onSubmit() {
  console.log(this.user);
  this.service.Login(this.user).subscribe(
    (response: any) => {
      console.log(response);
      if (response) {
        this.hidden_email=this.user.email
        console.log(this.hidden_email)
        this.service.Auth(this.user).subscribe(
          (data: any) => {
            console.log(data);
              this.validation=false;
            this.qrCodeUrl = data.data.qrCodeUrl;
            console.log(this.qrCodeUrl);
            this.showMessage = true;



            localStorage.setItem('userId', response.data.user.id);
           /* setTimeout(() => {
              this.gotoClasseList();
            }, 3000);*/
          },
          (error: any) => {
            // Gérez les erreurs de la requête 'Auth' ici
          }
        );
      } else {
        // L'e-mail n'existe pas, affichez un message d'erreur ou effectuez une action appropriée
      }
    },
    (error: any) => {
      // Gérez les erreurs de la requête 'Login' ici
    }
  );
}

verify2FA() {
  console.log(this.user.email);

  this.service.Verify(this.user).subscribe(
    (response: any) => {
      if (response.data.otp_valid === true) {
        setTimeout(() => {
          this.gotoClasseList();
        }, 3000);
      } else {
        if (response.status === "fail") {
         
        } else {
          // Gérer d'autres cas d'erreur potentiels
          console.error("Une erreur s'est produite lors de la vérification 2FA.", response);
        }
      }
    },
    (error) => {
      // Gérer les erreurs de l'appel API
       this.message = true;
          alert("code incorrect");
      console.error("Erreur lors de l'appel à la vérification 2FA.", error);
    }
  );
}
   gotoClasseList() {


    this.router.navigate(['dashboard']);
  }

}
