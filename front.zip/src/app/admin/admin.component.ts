import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Folder } from '../folder/folder';
import { FolderService } from '../service/folder.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent {
  folder: Folder;
  folders: any;

  constructor(
    private service: FolderService,
    private router: Router
  ) {
    this.folder = new Folder();
  }

  ngOnInit() {
    this.findAllOneUser();
  }

  onSubmit() {
    if (this.folder.name != null) {
      const userId = localStorage.getItem('userId');
      if (userId) {
        const userIdNumber = parseInt(userId, 10);
        this.service.createFolder(this.folder, userIdNumber).subscribe(
          (result) => {
            this.router.navigate(['dashboard']);
           
            this.refreshPage();
          }
        );
      } else {
        alert('Please try again. Make sure the email is not empty, the name contains at least 8 characters, and the password is at least 8 characters.');
      }
    }
  }



  gotoClasseList() {
    // Implement your logic here
  }

  gotoFile(id: number) {
    this.router.navigate(['file', id]);
  }

  findAllOneUser() {
    const userId = localStorage.getItem('userId');
    if (userId) {
      const userIdNumber = parseInt(userId, 10);
      this.service.select(userIdNumber).subscribe(
        (response) => {
          console.log(response);
          this.folders = response;
        },
        (error) => {
          console.error(error);
        }
      );
    } else {
      console.error('User ID not found in local storage');
    }
  }

  refreshPage() {
    window.location.reload();
  }

  deleteItem(id: number) {
  this.service.delete(id).subscribe(
    (response) => {
      // Gérer la réponse de succès
      this.refreshPage();
      console.log('Item supprimé avec succès', response);
      // Mettre à jour la liste des items ou effectuer d'autres actions nécessaires
    },
    (error) => {
      // Gérer les erreurs
      console.error('Erreur lors de la suppression de dossier', error);
    }
  );
}
}