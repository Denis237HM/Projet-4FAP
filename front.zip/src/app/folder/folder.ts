export class Folder {

  name!: string;
}
