import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../folder/user';
import { UserService } from '../service/user.service';


@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrl: './sign-up.component.css'
})
export class SignUpComponent {
  user: User;
  constructor(private service: UserService,   private router: Router) {
    this.user = new User();
   }
  createUser() {
    const user = {
      firstName: 'John',
      lastName: 'Doe',
      email: 'john.doe@example.com',
      password: 'password'
    };


  }
  showMessage: boolean = false;
  onSubmit() {
    if (this.user.email != null ) {
      // Vérification de l'email unique
      this.service.createUser(this.user).subscribe(
        result => {
          this.showMessage = true;
          setTimeout(() => {
            this.gotoClasseList();
          }, 3000); // Délai de 3 secondes (3000 millisecondes)
        }
      );
    } else {
      alert("Veuillez recommencer. Assurez-vous que l'email n'est pas vide, que le nom contient au moins 8 caractères et que le mot de passe a au moins 8 caractères.");
    }
  }
  gotoClasseList() {


    this.router.navigate(['signIn']);
  }

}
