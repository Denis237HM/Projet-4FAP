import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Folder } from './folder/folder';
import { FolderService } from './service/folder.service';

@Component({
  selector: 'app-view',
  templateUrl: `./appview.component.html`,
  styleUrls: ['./app.component.css']
})
export class AppviewComponent {
  title = 'dropzone';
  folder: Folder;
  id: any;
  folderId: any;
  selectedFile: File | null = null;
  getFiles:any;
  collaborateur:any;

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
    this.getFilesByFolderId();
    this.refreshPage

  }

  constructor(
    private route: ActivatedRoute,
    private service: FolderService,
    private router: Router
  ) {
    this.folder = new Folder();
  }

  onSelect(event: any) {
    console.log(event);
    this.selectedFile = event.addedFiles[0];
  }

  onRemove(event: any) {
    console.log(event);
    this.selectedFile = null;
  }


 downloadFile(filePath: string | undefined) {
  if (!filePath) {
    // Gérer le cas où filePath est indéfini
    return;
  }


  const fileUrl = `http://localhost:8000/${this.id}/${filePath}`;

  // Créer un lien de téléchargement temporaire
  const downloadLink = document.createElement('a');
  downloadLink.href = fileUrl;
  downloadLink.download = filePath.split('/').pop() ?? 'download';
    downloadLink.setAttribute('target', '_blank');
  downloadLink.setAttribute('download', ''); // Utiliser le nom de fichier à partir du chemin, ou 'download' par défaut si filePath est undefined

  // Ajouter le lien temporaire au document
  document.body.appendChild(downloadLink);

  // Déclencher le clic sur le lien pour lancer le téléchargement
  downloadLink.click();

  // Supprimer le lien temporaire du document
  document.body.removeChild(downloadLink);
}
uploadFile() {
  this.folderId = this.id;
  if (this.selectedFile) {
    const formData = new FormData();
    formData.append('file', this.selectedFile, this.selectedFile.name);
    formData.append('folderId', this.folderId.toString());
    console.log('Filename:', this.selectedFile.name);
    console.log('FolderId:', this.folderId);

    this.service.uploadFile(this.id, formData).subscribe(
      (response) => {
        console.log('File uploaded successfully!', response);
        console.log('FolderId:', response.folderId);

        // Reset the selectedFile
        this.selectedFile = null;

       this.getFilesByFolderId();
      },
      (error) => {
        console.error('Error uploading file:', error);
      }
    );
  }

}
  getFilesByFolderId() {
    this.service.selectFile(this.id).subscribe(
      files => {
        this.getFiles = files;
      },
      error => {
        console.error('Erreur lors de la récupération des fichiers :', error);
      }
    );
  }

    refreshPage() {
    window.location.reload();
  }

   deleteItem(id: number) {
  this.service.deleteFile(id).subscribe(
    (response) => {
      // Gérer la réponse de succès
      this.refreshPage();
      console.log('Item supprimé avec succès', response);
      // Mettre à jour la liste des items ou effectuer d'autres actions nécessaires
    },
    (error) => {
      // Gérer les erreurs
      console.error('Erreur lors de la suppression de dossier', error);
    }
  );
}

//add collaborator

 
  onSubmit() {
    const folderData = {
      collaborateur: this.collaborateur
    };

    this.service.update(folderData, this.folderId)
      .subscribe(
        (response) => {
          // Gérer la réponse de la mise à jour
          console.log(response);
        },
        (error) => {
          // Gérer les erreurs
          console.error(error);
        }
      );
  }
}