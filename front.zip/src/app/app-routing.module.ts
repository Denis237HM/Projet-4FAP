import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { SignInComponent } from './sign-in/sign-in.component';
import { SignUpComponent } from './sign-up/sign-up.component';

import { AppviewComponent } from './appview.component';

const routes: Routes = [
  {path:"signUp", component: SignUpComponent},
   // {path:"", component: AppviewComponent},
  {path:"signIn", component: SignInComponent},
  {path:"dashboard", component: AdminComponent},
  {path:"file/:id", component: AppviewComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
